from ufc_data_scraper.data_models.fighter.fighter import Fighter
from ufc_data_scraper.data_models.fighter.record import Record
from ufc_data_scraper.data_models.fighter.physical_stats import PhysicalStats
from ufc_data_scraper.data_models.fighter.striking import Striking
from ufc_data_scraper.data_models.fighter.strike_target import StrikeTarget
from ufc_data_scraper.data_models.fighter.strike_position import StrikePosition
from ufc_data_scraper.data_models.fighter.grappling import Grappling
from ufc_data_scraper.data_models.fighter.win_method import WinMethod
